package com.example.springboottls

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringbootTlsApplication

fun main(args: Array<String>) {
    runApplication<SpringbootTlsApplication>(*args)
}
